<?php

class Index_Model extends Model
{
	public function __construct()
	{
		parent::__construct();
	}
 
	   
		
		
		
			
		
	
	//end of class	
}